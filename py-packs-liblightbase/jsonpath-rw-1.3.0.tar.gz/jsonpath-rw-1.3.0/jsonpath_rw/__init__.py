from .jsonpath import *
from .parser import parse

__version__ = '1.3.0'
